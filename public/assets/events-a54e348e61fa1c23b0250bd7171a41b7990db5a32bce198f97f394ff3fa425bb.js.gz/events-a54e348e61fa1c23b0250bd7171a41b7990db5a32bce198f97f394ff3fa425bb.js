/* global $ */


$(document).ready(function() {
    $('#accd').accordion();
});
