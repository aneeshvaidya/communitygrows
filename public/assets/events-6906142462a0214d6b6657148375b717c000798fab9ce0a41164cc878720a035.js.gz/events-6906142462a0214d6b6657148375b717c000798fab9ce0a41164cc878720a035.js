/* global $ */


$(document).ready(function() {
    $('.ui-accordion').accordion({autoHeight: 'false', heightStyle: 'content'});
});
