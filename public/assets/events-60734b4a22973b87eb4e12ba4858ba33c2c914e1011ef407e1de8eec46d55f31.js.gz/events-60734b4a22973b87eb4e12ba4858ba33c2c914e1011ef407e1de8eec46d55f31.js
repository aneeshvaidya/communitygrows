/* global $ */


$(document).ready(function() {
    $('.ui-accordion').accordion();
});
